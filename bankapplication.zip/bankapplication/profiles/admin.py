from django.contrib import admin
from .models import createProfileModel
# Register your models here.
admin.site.register(createProfileModel)